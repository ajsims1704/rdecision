## ---- include = FALSE----------------------------------------------------
rm(list=ls())
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=F-------------------------------------------------------
library('rdecision')

## ----variables, echo=T---------------------------------------------------
# clinical variables
r.CRBSI <- NormalModelVariable$new(
  'r.CRBSI', 'Baseline CRBSI rate', '/1000 catheter days', mu=1.48, sigma=0.074
)
hr.CRBSI <- LogNormalModelVariable$new(
  'hr.CRBSI', 'Tegaderm CRBSI HR', 'ratio', p1=-0.911, p2=0.393
)
r.LSI <- NormalModelVariable$new(
  'r.LSI', 'Baseline LSI rate', '/patient', mu=0.1, sigma=0.01
)
hr.LSI <- LogNormalModelVariable$new(
  'hr.LSI', 'Tegaderm LSI HR', 'ratio', p1=-0.911, p2=0.393
)
r.Dermatitis <- NormalModelVariable$new(
  'r.Dermatitis', 'Baseline dermatitis risk', '/catheter', 
  mu=0.0026, sigma=0.00026
)
rr.Dermatitis <- LogNormalModelVariable$new(
  'rr.Dermatitis', 'Tegaderm Dermatitis RR', 'ratio',  p1=1.482, p2=0.490
)

# cost variables
c.CRBSI <- GammaModelVariable$new(
  'c.CRBSI', 'CRBSI cost', 'GBP', alpha=198.0, beta=50
)
c.Dermatitis <- GammaModelVariable$new(
  'c.Dermatitis', 'Dermatitis cost', 'GBP', alpha=30, beta=5
)
c.LSI <- GammaModelVariable$new(
  'c.LSI', 'LSI cost', 'GBP', alpha=50, beta=5
)
c.Tegaderm <- ConstModelVariable$new(
  'c.Tegaderm', 'Tegaderm CHG cost', 'GBP', const=6.21
)
c.Standard <- ConstModelVariable$new(
  'c.Standard', 'Standard dressing cost', 'GBP', const=1.34
)
n.cathdays <- NormalModelVariable$new(
  'n.cathdays', 'No. days with catheter', 'days', mu=10, sigma=2
)
n.dressings <- NormalModelVariable$new(
  'n.dressings', 'No. dressings', 'dressings', mu=3, sigma=0.3
)

## ----expressions, echo=TRUE----------------------------------------------
# probabilities
p.Dermatitis.S <- ExpressionModelVariable$new(
  'p.Dermatitis.S', 'P(dermatitis|standard dressing)', 'P', 
  quote(n.dressings*r.Dermatitis)
)
p.Dermatitis.T <- ExpressionModelVariable$new(
  'p.Dermatitis.T', 'P(dermatitis|Tegaderm)', 'P',
  quote(n.dressings*r.Dermatitis*rr.Dermatitis)
)
r.LSI.T <- ExpressionModelVariable$new(
  'r.LSI.T', 'P(LSI|Tegaderm)', 'P',
 quote(r.LSI*hr.LSI)
)
p.CRBSI.S <- ExpressionModelVariable$new(
  'p.CRBSI.S', 'P(CRBSI|standard dressing)', 'P',
  quote(r.CRBSI*n.cathdays/1000)
)
p.CRBSI.T <- ExpressionModelVariable$new(
  'p.CRBSI.T', 'P(CRBSI|Tegaderm)', 'P', 
  quote(r.CRBSI*n.cathdays*hr.CRBSI/1000)
)

# costs
c.S <- ExpressionModelVariable$new(
  'c.S', 'Cost of standard dressing', 'GBP',
  quote(n.dressings*c.Standard)
)
c.T <- ExpressionModelVariable$new(
  'c.T', 'Cost of Tegaderm', 'GBP',
  quote(n.dressings*c.Tegaderm)
)

## ----tree, echo=T--------------------------------------------------------
# standard dressing branch
leaf.S.Dermatitis <- LeafNode$new('Dermatitis (Standard Dressing)')
leaf.S.LSI <- LeafNode$new('Local site infection (Standard Dressing)')
leaf.S.CRBSI <- LeafNode$new('CRBSI (Standard Dressing)')
leaf.S.NoComp <- LeafNode$new('No complication (Standard Dressing)')

chance.S <- ChanceNode$new(
  children = list(leaf.S.Dermatitis, leaf.S.LSI, leaf.S.CRBSI, leaf.S.NoComp),
  edgelabels = c('Dermatitis', 'Local site infection', 'CRBSI', 'No complication'),
  costs = list(c.Dermatitis, c.LSI, c.CRBSI, 0),
  p = list(p.Dermatitis.S, r.LSI, p.CRBSI.S, NA)
)

# Tegaderm dressing branch
leaf.T.Dermatitis <- LeafNode$new('Dermatitis (Tegaderm CHG)')
leaf.T.LSI <- LeafNode$new('Local site infection (Tegaderm CHG)')
leaf.T.CRBSI <- LeafNode$new('CRBSI (Tegaderm CHG)')
leaf.T.NoComp <- LeafNode$new('No complication (Tegaderm CHG)')

chance.T <- ChanceNode$new(
  children = list(leaf.T.Dermatitis, leaf.T.LSI, leaf.T.CRBSI, leaf.T.NoComp),
  edgelabels = c('Dermatitis', 'Local site infection', 'CRBSI', 'No complication'),
  costs = list(c.Dermatitis, c.LSI, c.CRBSI, 0),
  p = list(p.Dermatitis.T, r.LSI.T, p.CRBSI.T, NA)
)

# decision node
d <- DecisionNode$new(
  children = list(chance.S, chance.T),
  edgelabels = c('Standard', 'Tegaderm'),
  costs = list(c.S, c.T)
)

## ----modelinputs-structure, echo=FALSE-----------------------------------
local({
  DF <- d$tabulateModelVariables(include.descendants=T, include.operands=T)
  keep <- c('Description', 'Label', 'Distribution')
  knitr::kable(DF[,keep], row.names=F, format.args=list(scientific=F), digits=3)
})

## ----modelinputs-pe, echo=FALSE------------------------------------------
local({
  DF <- d$tabulateModelVariables(include.descendants=T, include.operands=T)
  keep <- c('Description', 'Units', 'Mean', 'Q2.5', 'Q97.5', 'Qhat')
  knitr::kable(DF[,keep], row.names=F, format.args=list(scientific=F), digits=3)
})

## ----basecase, echo=FALSE------------------------------------------------
local({
  RES <- d$evaluatePathways(expected=T)
  keep <- c('Choice', 'Pathway', 'Probability', 'Cost', 'ExpectedCost')
  knitr::kable(RES[,keep], digits=c(NA, NA, 4, 2, 2))
})

## ----basecase-summary, echo=FALSE----------------------------------------
PE.saving <- 0
local({
  SUM <- d$evaluateChoices(expected=T)
  PE.saving <<- SUM$Cost[SUM$Choice=='Tegaderm'] - 
                SUM$Cost[SUM$Choice=='Standard']
})

## ----PSA, echo=FALSE-----------------------------------------------------
local({
  PSA <- d$evaluateChoices(expected=F, uncorrelate=F, N=1000)
  RES <<- reshape(PSA, idvar='Run', timevar='Choice', direction='wide')
  RES$Difference <<- RES$Cost.Tegaderm - RES$Cost.Standard
  keep<- c('Run', 'Cost.Tegaderm', 'Cost.Standard', 'Difference')
  knitr::kable(head(RES[,keep], n=10), digits=2, row.names=F)
})

## ----echo=F--------------------------------------------------------------
rm(RES)

## ----treefree, echo=TRUE-------------------------------------------------
# component costs, standard dressing
CHG.S <- ExpressionModelVariable$new(
  'CHG.S', "Cost of standard dressing", "GBP", 
  quote(n.dressings*c.Standard)
)
CRBSI.S <- ExpressionModelVariable$new(
  'CRBSI.S', "Cost of CRBSI, standard dressing", "GBP", 
  quote(c.CRBSI*r.CRBSI*n.cathdays/1000)
)
LSI.S <- ExpressionModelVariable$new(
  'LSI.S', "Cost of LSI, standard dressing", "GBP", 
  quote(c.LSI*r.LSI)
)
Dermatitis.S <- ExpressionModelVariable$new(
  'Dermatitis.S', "Cost of dermatitis, standard dressing", "GBP",
  quote(r.Dermatitis*c.Dermatitis*n.dressings)
)

# component costs, Tegaderm
CHG.T <- ExpressionModelVariable$new(
  'CHG.T', "Cost of Tegaderm", "GBP", 
  quote(n.dressings*c.Tegaderm)
)
CRBSI.T <- ExpressionModelVariable$new(
  'CRBSI.T', "Cost of CRBSI, Tegaderm", "GBP", 
  quote(c.CRBSI*r.CRBSI*hr.CRBSI*n.cathdays/1000)
)
LSI.T <- ExpressionModelVariable$new(
  'LSI.T', "Cost of LSI, Tegaderm", "GBP", 
  quote(c.LSI*r.LSI*hr.LSI)
)
Dermatitis.T <- ExpressionModelVariable$new(
  'Dermatitis.T', "Cost of dermatitis, Tegaderm", "GBP",
  quote(r.Dermatitis*c.Dermatitis*rr.Dermatitis*n.dressings)
)

# per-patient costs
total.T <- ExpressionModelVariable$new(
  'total.T','Treatment cost (Tegaderm)', 'GBP',
  quote(CHG.T+CRBSI.T+LSI.T+Dermatitis.T)
)
total.S <- ExpressionModelVariable$new(
  'total.S','Treatment cost (Standard)', 'GBP',
  quote(CHG.S+CRBSI.S+LSI.S+Dermatitis.S)
)
c.diff <- ExpressionModelVariable$new(
  'c.diff', 'Cost difference', 'GBP',
  quote(total.T-total.S)
)

## ----treefree-base, echo=FALSE-------------------------------------------
local({
  MV <- c.diff$tabulate(include.operands=TRUE)
  vars <- c('CHG.S', 'CRBSI.S', 'LSI.S', 'Dermatitis.S',
            'CHG.T', 'CRBSI.T', 'LSI.T', 'Dermatitis.T',
            'total.S', 'total.T', 'c.diff')
  keep <- c('Description', 'Units', 'Mean', 'SD', 'Q2.5', 'Q97.5', 'Qhat')
  knitr::kable(MV[MV$Label %in% vars, keep], row.names=F, 
               format.args=list(scientific=F), digits=2
               )
})

## ----echo=FALSE----------------------------------------------------------
tf.psa <- c.diff$r(1000)

## ----CORR, echo=FALSE----------------------------------------------------
local({
  PSA <- d$evaluateChoices(expected=F, uncorrelate=F, N=1000)
  RES.C <<- reshape(PSA, idvar='Run', timevar='Choice', direction='wide')
  RES.C$Difference <<- RES.C$Cost.Tegaderm - RES.C$Cost.Standard
  R.C <<- cor(RES.C$Cost.Tegaderm, RES.C$Cost.Standard)

  PSA <- d$evaluateChoices(expected=F, uncorrelate=T, N=1000)
  RES.U <<- reshape(PSA, idvar='Run', timevar='Choice', direction='wide')
  RES.U$Difference <<- RES.U$Cost.Tegaderm - RES.U$Cost.Standard
  R.U <<- cor(RES.U$Cost.Tegaderm, RES.U$Cost.Standard)
  
  sd.T <<- sd(RES.C$Cost.Tegaderm)
  sd.S <<- sd(RES.C$Cost.Standard)
  cov.TS <<- cov(RES.C$Cost.Tegaderm, RES.C$Cost.Standard)  
})

## ----CORREND, echo=FALSE-------------------------------------------------
rm(RES.C, RES.U, R.C, R.U, sd.T, sd.S, cov.TS)

