#' @name pathway.cost
#' 
#' @title Calculate pathway cost from decision and chance nodes.
#' 
#' @description Calculates the sum of the pathways costs in
#' the tree traversal.
#' 
#' @note Assumes that the final node is a leaf node.
#' 
#' @param nodes List of nodes in the node-to-leaf traversal path.
#' 
#' @export
pathway.cost <- function(nodes) {
  # cost value to return
  cost <- 0
  # step through each node in the path
  for (i in 1:(length(nodes)-1)){
    n <- nodes[[i]]
    # if chance node, get cost for the path to the next node
    if (class(n)[1] %in% c('ChanceNode', 'DecisionNode')) {
      next.node <- nodes[[i+1]]
      # find which child node is linked to the next in the tree
      j <- which.node(n$children, next.node)
      if (!is.na(j)) {
        cost <- cost + n$costs[[j]]
      }
    }
  }
  return(cost)
}
