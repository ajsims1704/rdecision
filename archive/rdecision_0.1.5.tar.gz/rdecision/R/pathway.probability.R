#' @name pathway.probability
#' 
#' @title Calculate pathway probability from conditional probabilities.
#' 
#' @description Calculates the product of the conditional P values in
#' the tree traversal.
#' 
#' @note Assumes the nodes are supplied in order of traversal and that
#' the final node is a leaf node.
#' 
#' @param nodes List of nodes in the node-to-leaf traversal path.
#' 
#' @export
pathway.probability <- function(nodes) {
  # p value to return
  p <- 1
  # step through each node in the path except the last
  for (i in 1:(length(nodes)-1)){
    n <- nodes[[i]]
    # if chance node, get p for the path to the next node
    if (class(n)[1]=='ChanceNode') {
      next.node <- nodes[[i+1]]
      # find which child node is linked to the next in the tree
      j <- which.node(n$children, next.node)
      if (!is.na(j)) {
        p <- p * n$p[[j]]
      }
    }
  }
  return(p)
}
