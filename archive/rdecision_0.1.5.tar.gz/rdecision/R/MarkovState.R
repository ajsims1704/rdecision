#' @name MarkovState
#' @title An R6 class for a state in a Markov model
#' @name MarkovState
#' @docType class
#' @field name the name of the state (character string)
#' @field hasCycleLimit (logical) TRUE if the state is a tunnel state
#' @field cycleLimit (numeric) the maximum length of stay (1 for cohort tunnel states)
#' @field entryCost the cost to enter the state
#' @field annualCost the annual cost of state occupancy
#' @section Methods:
#' \describe{
#'   \item{setAnnualCost}{Sets the annual cost of state occupancy}
#' } 
#' \describe{
#'   \item{setEntryCost}{Sets the entry cost of state occupancy}
#' } 
#' \describe{
#'   \item{getEntryCost}{Gets the entry cost of state occupancy}
#' } 
#' @export 

MarkovState <- R6::R6Class(
  classname = "MarkovState", 
  public = list(
    name = "character",
    hasCycleLimit = "logical",
    cycleLimit = "numeric",
    annualCost = "numeric",
    entryCost = "numeric",
    initialize = function(name, annualCost=0, entryCost=0, hasCycleLimit=F, cycleLimit=NA) {
      # set the name
      self$name <- name 
      # set the cycle limit state and value (for tunnel states)
      self$hasCycleLimit <- hasCycleLimit
      self$cycleLimit <- cycleLimit
      # check that annual cost is numeric, then set it
      if (!is.numeric(annualCost)){
        stop("`annualCost` must be of type `numeric`")
      }
      self$annualCost<- annualCost
      # check that entry cost is numeric, then set it
      if (!is.numeric(entryCost)){
        stop("`entryCost` must be of type `numeric`")
      }
      self$entryCost<- entryCost
    },
    setAnnualCost = function(annualCost) {
      # check that cost is numeric, then set it
      if (!is.numeric(annualCost)){
        stop("`annualCost` must be of type `numeric`")
      }
      self$annualCost<- annualCost
    },
    setEntryCost = function(entryCost) {
      # check that cost is numeric, then set it
      if (!is.numeric(entryCost)){
        stop("`entryCost` must be of type `numeric`")
      }
      self$entryCost<- entryCost
    },
    getEntryCost = function() {
      return(self$entryCost)
    }
  )
)