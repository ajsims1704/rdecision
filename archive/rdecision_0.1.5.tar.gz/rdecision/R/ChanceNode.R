#' @description An R6 class for a chance node in a decision tree
#' @name ChanceNode
#' @docType class
#' @inherit Node
#' @field p a list of proportions associated with each chance outcome
#' @field edgelabels a vector of character stings containing the labels
#'                   of each chance outcome associated with the node
#' @field costs a vector of numeric values containing the costs associated
#'              with each choice
#' @export 
ChanceNode <- R6::R6Class(
  classname = "ChanceNode",
  inherit = Node,
  public = list(
    p = "list",
    edgelabels = "list",
    costs = "list",
    initialize = function(p, children, edgelabels, costs) {
      self$p <- p
      self$children <- children
      self$edgelabels <- edgelabels
      self$costs <- costs
    }
  )
)
# validChanceNode <- function(object) {
#   if (length(object$children) < 2) {
#     stop("`children` must contain at least two objects of class `Node`.")
#   }
#   sapply(object$children, function(x) {
#     if (inherits(x, what="Node")==F){
#       stop("Each element in `children` must be of class `Node`")
#     }
#   })
#   if (length(object$p) != length(object$children)) {
#     stop("`p` must contain the same number of objects as `children`.")
#   }
#   sapply(object$p, function(x) {
#     if (!is.numeric(x)){
#       stop("Each element in `p` must be of class `numeric`.")
#     }
#   })
#   if (sum(unlist(object$p)) != 1) {
#     stop("Elements in `p` must sum to unity.")
#   }
#   if (length(object$edgelabels) != length(object$children)) {
#     stop("`edgelabels` must contain the same number of objects as `children`.")
#   }
#   if (length(object$costs) != length(object$children)) {
#     stop("`costs` must contain the same number of objects as `children`.")
#   }
#   sapply(object$costs, function(x) {
#     if (!is.numeric(x)){
#       stop("Each element in `costs` must be of class `numeric`")
#     }
#   })
#   return(T)
# }
# setValidity("ChanceNode", validChanceNode)
