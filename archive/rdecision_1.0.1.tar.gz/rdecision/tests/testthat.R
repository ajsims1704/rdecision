library(testthat)
library(rdecision)
test_check("rdecision")
