#' @title An R6 class to represent a node in a decision tree
#' @name Node
#' @docType class
#' @field children a list of child nodes.
#' @export 
Node <- R6::R6Class(
  classname = "Node", 
  public=list(
    children = "list"
  )
)
