#' @name MarkovState
#' @title An R6 class for a state in a Markov model
#' @name MarkovState
#' @docType class
#' @field name the name of the state (character string)
#' @field annualCost the annual cost of state occupancy
#' @section Methods:
#' \describe{
#'   \item{setCost}{Blah blah}
#' } 
#' @export 

MarkovState <- R6::R6Class(
  classname = "MarkovState", 
  public = list(
    name = "character",
    annualCost = "numeric",
    initialize = function(name, annualCost=0) {
      # set the name
      self$name <- name 
      # check that cost is numeric, then set it
      if (!is.numeric(annualCost)){
        stop("`annualCost` must be of type `numeric`")
      }
      self$annualCost<- annualCost
    },
    setCost = function(annualCost) {
      # check that cost is numeric, then set it
      if (!is.numeric(annualCost)){
        stop("`annualCost` must be of type `numeric`")
      }
      self$annualCost<- annualCost
    }
  )
)