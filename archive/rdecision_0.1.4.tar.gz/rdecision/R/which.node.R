#' @name which.node
#' @title Find the index of a node object in a list of node objects
#' @description Returns the index of node in a list of nodes.
#' @param nodes list of objects of type Node
#' @param node node of type Node to search for in \code{nodes}
#' @return index of first occurrence of \code{node} in \code{nodes} or
#'         NA if not present
#' @export
which.node <- function(nodes, node) {
  rc <- NA
  for (j in 1:length(nodes)) {
    c <- nodes[[j]]
    if (identical(c, node)) {
      rc <- j
      break
    }
  }
  return(rc)
}
