# -----------------------------------------------------------------------------
# make.R
#
# Description:
# ============
# R script which uses the 'devtools' library to build the package.
#
# History:
# ========
# 14.05.2019. A.J. Sims.
# ----------------------------------------------------------------------------

rm(list=ls())

local({
  # set working directory to package source
  setwd("h:/Sources/rdecision")

  # build documentation (identifies errors in documentation which can
  # upset the build process)
  devtools::document()
  
  # build package with vignettes
  devtools::build(path='../repository', binary=F, vignettes=T)

  # build windows binary package (will not contain vignettes or manual)
  devtools::build(path='../repository', binary=T)

  # build documentation
  #devtools::build_vignettes()
  #devtools::build_manual()
  #devtools::document()

  # build package without vignettes
  #devtools::build(path='../repository', binary=F, vignettes=F)

  # install package
  #install.packages()
  # build documentation
  #devtools::build_vignettes()
  #devtools::build_manual()
  #devtools::document()
  
  
})

