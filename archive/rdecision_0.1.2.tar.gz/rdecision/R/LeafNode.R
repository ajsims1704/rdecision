#' @title An R6 class for a leaf node in a decision tree
#' @name LeafNode
#' @docType class
#' @inherit Node
#' @field pathway character string; a label for the leaf node which is
#'                synonymous with the name of the root-to-leaf pathway
#' @field utility the preference or value that a user associates with
#'                a given health state (tange 0 to 1).
#' @export
LeafNode <- R6::R6Class(
  classname = "LeafNode",
  inherit = Node,
  public = list(
    pathway = "character",
    utility = "numeric",
    initialize = function(name, utility=1) {
      self$pathway <- name
      self$utility <- utility
      self$children <- list()
    }
  )
 )
# validLeafNode <- function(object) {
#   if (length(object$children) != 0) {
#     stop("LeafNodes must have zero `children`.")
#   }
#   return(T)
# }
# setValidity("LeafNode", validLeafNode)
