#' @name DecisionNode
#' @title An R6 class for a decision node in a decision tree
#' @docType class
#' @inherit Node
#' @field edgelabels a vector of character stings containing the labels
#'                   of each choice associated with the decision
#' @field costs a vector of numeric values containing the costs associated
#'              with each choice
#' @format An R6 class
#' @export
DecisionNode <- R6::R6Class(
  classname = "DecisionNode",
  inherit = Node,
  public = list(
    edgelabels = "list",
    costs = "list",
    initialize = function(children, edgelabels, costs) {
      self$children <- children
      self$edgelabels <- edgelabels
      self$costs <- costs
    }
  )
)
# validDecisionNode <- function(object) {
#   if (length(object$children) == 0) {
#     stop("`children` must contain at least one object of class `Node`.")
#   }
#   sapply(object$children, function(x) {
#     if (inherits(x, what="Node")==F){
#       stop("Each element in `children` must be of class `Node`")
#     }
#   })
#   if (length(object$children) != length(object$edgelabels)) {
#     stop("`edgelabels` must contain the same number of objects as `children`.")
#   }
#   if (length(object$costs) != length(object$children)) {
#     stop("`costs` must contain the same number of objects as `children`.")
#   }
#   sapply(object$costs, function(x) {
#     if (!is.numeric(x)){
#       stop("Each element in `costs` must be of class `numeric`")
#     }
#   })
#   return(T)
# }
# setValidity("DecisionNode", validDecisionNode)
