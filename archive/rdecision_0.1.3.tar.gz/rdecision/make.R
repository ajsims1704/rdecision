# -----------------------------------------------------------------------------
# make.R
#
# Description:
# ============
# R script which uses the 'devtools' library to build the package.
#
# History:
# ========
# 14.05.2019. A.J. Sims.
# ----------------------------------------------------------------------------

rm(list=ls())

local({
  # set working directory to package source
  setwd("//rmpdfh-home1/simsa/Sources/rdecision")
  
  # build documentation
  devtools::build_vignettes()
  devtools::build_manual()
  devtools::document()

  # build source package
  devtools::build(path='../repository', binary=F, vignettes=T)
  
  # build windows binary package (will not contain vignettes or manual)
  devtools::build(path='../repository', binary=T)
  
})

