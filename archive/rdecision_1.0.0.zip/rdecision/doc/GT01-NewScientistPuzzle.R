## ---- include = FALSE----------------------------------------------------
rm(list=ls())
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, echo=F-------------------------------------------------------
library("rdecision")
library("grid")

## ----diagram, echo=FALSE, results='hide', fig.keep='last', out.width="8cm", fig.width=12, fig.height=12, fig.align='center'----
# viewport
vp <- viewport(
  width = 300,
  height = 300,
  default.units = "mm"
)
# grid
for (x in seq(50,250,50)) {
  grid.move.to(x=unit(x,"mm"), y=unit(50,"mm"), vp=vp)
  grid.line.to(x=unit(x,"mm"), y=unit(250,"mm"), gp=gpar(lwd=2), vp=vp)
}
for (y in seq(50,250,50)) {
  grid.move.to(x=unit(50,"mm"), y=unit(y,"mm"), vp=vp)
  grid.line.to(x=unit(250,"mm"), y=unit(y,"mm"), gp=gpar(lwd=2), vp=vp)
}
grid.text(label="A", x=unit(45,"mm"), y=unit(255,"mm"), gp=gpar(fontsize=40))
grid.text(label="B", x=unit(255,"mm"), y=unit(45,"mm"), gp=gpar(fontsize=40))
# restaurants
BB <- data.frame(
  x0 = c(150,100,210,160,250,110,50),
  y0 = c(60,110,100,150,160,200,210),
  x1 = c(150,100,240,190,250,140,50),
  y1 = c(90,140,100,150,190,200,240)
)
apply(BB, MARGIN=1, function(r){
  grid.move.to(x=unit(r["x0"],"mm"), y=unit(r["y0"],"mm"), vp=vp)
  grid.line.to(x=unit(r["x1"],"mm"), y=unit(r["y1"],"mm"), 
               gp=gpar(col="red", lwd=6, lend="square"), vp=vp)
})
# display
pushViewport(vp)
popViewport()

## ----construct-graph, echo=TRUE------------------------------------------
# create vertices
V <- list()
for (i in 1:5) {
  for (j in 1:5) {
    V <- c(V, Node$new(paste("N",i,j,sep="")))
  }
}
# create edges
E <- list()
for (i in 1:5) {
  for (j in 1:4) {
    E <- c(E, Arrow$new(V[[5*(i-1)+j]], V[[5*(i-1)+j+1]], paste("H",i,j,sep="")))
  }
} 
for (i in 1:4) {
  for (j in 1:5) {
    E <- c(E, Arrow$new(V[[5*(i-1)+j]], V[[5*i+j]], paste("V",i,j,sep="")))
  }
} 
# create graph
G <- Digraph$new(V,E)

## ----findpaths, echo=TRUE------------------------------------------------
# get all paths from A to B
A <- V[[1]]
B <- V[[25]]
P <- G$paths(A,B)
# convert paths to walks
W <- lapply(P,function(p){G$walk(p)})
# count and tabulate how many special edges each walk traverses
BB <- c("V11", "H22", "V25", "H33", "V32", "H44", "V43")
nw <- sapply(W, function(w) {
  lv <- sapply(w, function(e) {e$label() %in% BB}) 
  return(sum(lv))
})
# tabulate 
ct <- as.data.frame(table(nw))

## ----echo=FALSE, results='markdown'--------------------------------------
names(ct) <- c("n", "frequency")
knitr::kable(ct)

